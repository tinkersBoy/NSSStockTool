//
//  DingPanViewController.swift
//  NSStockTool
//
//  Created by caojinguo on 2021/4/28.
//

import Foundation
import Cocoa

class NSSDingPanViewContoller: NSViewController {
    
    
}
