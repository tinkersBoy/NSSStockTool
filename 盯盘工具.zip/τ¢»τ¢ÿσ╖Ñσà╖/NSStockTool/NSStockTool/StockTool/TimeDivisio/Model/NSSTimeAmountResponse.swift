//
//  NSSTimeAmountResponse.swift
//  NSStockTool
//
//  Created by caojinguo on 2021/5/14.
//

import Foundation

class NSSTimeAmountResponse: NSSBaseModel {
    var data:Array<NSSTimeAmountModel>  = []
    var dataDict                        = Dictionary<String,Any>()
    var currentDate:String              = ""
}
