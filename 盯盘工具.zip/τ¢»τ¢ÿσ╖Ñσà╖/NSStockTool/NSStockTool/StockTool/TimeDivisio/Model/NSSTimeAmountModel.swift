//
//  NSSTimeAmountModel.swift
//  NSStockTool
//
//  Created by caojinguo on 2021/5/14.
//

import Foundation

class NSSTimeAmountModel: NSSBaseModel {
    var dateT:String         = ""   // 分时时间
    var amount:CGFloat       = 0.0  // 成交量
    var diff:CGFloat         = 0.0  // 成交量差值
    var amountStr:String       = ""
    var diffStr:String         = ""
}
