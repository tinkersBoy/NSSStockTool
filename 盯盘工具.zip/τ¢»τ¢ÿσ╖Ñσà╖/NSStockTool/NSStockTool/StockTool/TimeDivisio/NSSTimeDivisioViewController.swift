//
//  NSSTimeDivisioViewController.swift
//  NSStockTool
//
//  Created by caojinguo on 2021/5/14.
//

import Cocoa

class NSSTimeDivisioViewController: NSViewController  {
    var listView:NSSTimeAmountListView  = NSSTimeAmountListView.init()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let color : CGColor = CGColor.black
        view.layer?.backgroundColor = color
        
        self.listView.frame = NSRect(x: 1, y: 5.0,
                                width: 1200, height: 50.0)
        self.view.addSubview(self.listView)
        
        var timeInterval:TimeInterval = 0.5
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "HH"// 自定义时间格式
        let time = dateformatter.string(from: Date())
        let hour:Int = Int(time) ?? 10
        dateformatter.dateFormat = "mm"// 自定义时间格式
        let time1 = dateformatter.string(from: Date())
        let min:Int = Int(time1) ?? 0
        
        //
        if (hour <= 9 && min < 30) || (hour == 11 && min > 30) || (hour == 12) || (hour >= 15 && min > 1) {
            timeInterval = 5.0
            self.refreshData()
        }
        
        Timer.scheduledTimer(withTimeInterval: timeInterval, repeats: true) { timer in
//            print(">>> Timer has Callback!")
            self.refreshData()
        }
        
    }
    
    func refreshData() -> () {
        let response:NSSTimeAmountResponse = NSSTimeDivisionManager.sharedInstance.listResponse
        if response.data.count > 0 {
            let height:CGFloat        = self.listView.setContentData(listResponse: response)
            self.listView.height      = height + 10.0
        }
    }
    
    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }
}
