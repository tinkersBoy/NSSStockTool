//
//  NSSTimeAmountListView.swift
//  NSStockTool
//
//  Created by caojinguo on 2021/5/14.
//

import Foundation
import AppKit

class NSSTimeAmountListView: NSView {
    func setContentData(listResponse:NSSTimeAmountResponse) -> (CGFloat) {
        for view:NSView in self.subviews {
            view.removeFromSuperview()
        }
        var line:Int       = listResponse.data.count % 12
        if listResponse.data.count >= 12 {
            line = 12
        }
        let height:CGFloat = CGFloat(line) * 35.0
        var i = 0;
        let count = listResponse.data.count
        if count > 0 {
            for itemModel:NSSTimeAmountModel in listResponse.data {
                let timerItemView:NSSTimeAmountItemView = NSSTimeAmountItemView.init()
                timerItemView.frame             = NSRect(x: self.frameXWithIndex(i: i, count: count),
                                                         y: self.frameYWithIndex(i: i, height: Int(height)),
                                                         width: Int(128.0), height: Int(30.0))
                timerItemView.setContentData(itemModel: itemModel)
                self.addSubview(timerItemView)
                i = i + 1
            }
            
        }
        return height
    }
    
    func frameXWithIndex(i:Int,count:Int) -> Int {
        let column:Int     = i / 12
        let frameX:CGFloat = 1.0 + CGFloat(column) * 130.0
        return Int(frameX)
    }
    
    func frameYWithIndex(i:Int,height:Int) -> Int {
        let index:Int = i % 12
        let y:CGFloat    = (CGFloat(index) * 35.0)
        let frameY:CGFloat = CGFloat(height) - y - 35.0
        return Int(frameY)
    }
    
}
