//
//  NSSTimeAmountItemView.swift
//  NSStockTool
//
//  Created by caojinguo on 2021/5/14.
//

import Foundation
import AppKit

class NSSTimeAmountItemView: NSView {
    var infoLabel:NSTextField    = NSSTimeAmountItemView.defaultLab()
    var diffLabel:NSTextField    = NSSTimeAmountItemView.defaultLab()
    
    func setContentData(itemModel:NSSTimeAmountModel) -> () {
        let defaultColor:NSColor = NSSFormatUtil.defaultColor()
        let redColor:NSColor     = NSColor.stockRedColor()
        let greenColor:NSColor   = NSColor.stockGreenColor()
////        let normalColor:NSColor  = NSColor.systemGray
        let fontSize:CGFloat     = 12.0
//
//        var i = 0
        
        let amount:CGFloat          = itemModel.amount / 100000000.0;
        let amountStr:String        = String(format:"%.2f",amount) + "亿"
        self.infoLabel.attributed.string = NSSFormatUtil.stockAttributedstring(name: itemModel.dateT,
                                                                            dataStr: amountStr,
                                                                          nameColor: defaultColor,
                                                                          dataColor: defaultColor,
                                                                          dataFontSize: 10.0)
        let diffAmount:CGFloat    = itemModel.diff / 100000000.0;
        let diffAmountStr:String  = String(format:"%.2f",diffAmount) + "亿"
//        self.diffLabel.isHidden
        let diffColor:NSColor = (diffAmount >= 100.0) ? redColor : greenColor
        self.diffLabel.attributed.string = NSSFormatUtil.stockAttributedstring(name: diffAmountStr, nameColor: diffColor, fontSize: fontSize)
        
        self.diffLabel.x      = 63.0
        self.diffLabel.width  = 65.0
        self.addSubview(self.infoLabel)
        self.addSubview(self.diffLabel)
        
    }
    
    static  func defaultLab() -> NSTextField {
        let textField:NSTextField   = NSTextField.init()
        textField.frame             = NSRect(x: 1, y: 0.0,
                                            width: 60.0, height: 30.0)
        textField.isEnabled         = false
        return textField
    }
}
