//
//  NSSStockModel.swift
//  NSStockTool
//
//  Created by caojinguo on 2021/4/28.
//

import Foundation

class NSSStockModel: NSSBaseModel {
    var current:CGFloat      = 0.0 // 现价
    var amount:CGFloat       = 0.0 // 交易总额
    var chg:CGFloat          = 0.0 // 离当日开盘差价
    var high:CGFloat         = 0.0 // 高
    var low:CGFloat          = 0.0 // 低
    var open:CGFloat         = 0.0 // 开盘价
    var percent:CGFloat      = 0.0 // 涨幅百分比
    var symbol:NSString      = ""  // 股票代码
    var type:Int             = 0   // 类型: 1短线 2长线
}
