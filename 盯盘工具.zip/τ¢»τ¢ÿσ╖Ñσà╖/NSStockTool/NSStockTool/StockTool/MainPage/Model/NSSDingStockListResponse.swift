//
//  NSSDingStockListResponse.swift
//  NSStockTool
//
//  Created by caojinguo on 2021/4/29.
//

import Foundation

class NSSDingStockListResponse: NSSBaseModel {
    var data:Array<NSSDingStockModel> = []
    
//    required init() {}
    
    
}

class NSSDingStockModel: NSSBaseModel {
    var current:CGFloat      = 0.0 // 现价
    var amount:CGFloat       = 0.0 // 交易总额
    var chg:CGFloat          = 0.0 // 离当日开盘差价
    var high:CGFloat         = 0.0 // 高
    var low:CGFloat          = 0.0 // 低
    var open:CGFloat         = 0.0 // 开盘价
    var percent:CGFloat      = 0.0 // 涨幅百分比
    var risk:CGFloat         = 0.0 // 警戒位
    var symbol:NSString      = ""  // 股票代码
    var name:NSString        = ""  // 股票名称
    var hold:Array<String>  = [] // 支撑位
    var press:Array<String> = [] // 压力位
    var type:Int             = 0   // 类型: 1短线 2长线
}
