//
//  NSSFileConfigResponse.swift
//  NSStockTool
//
//  Created by caojinguo on 2021/4/29.
//

import Foundation

class NSSFileConfigResponse: NSSBaseModel {
    var list:Array<NSSConfigModel> = []
    var isLocalData:Bool           = false
    
//    required init() {}
    
    
}

class NSSConfigModel: NSSBaseModel {
    var symbol:String         = ""  // 股票代码
    var name:String           = ""  // 股票名称
    var hold:Array<String>   = [] // 支撑价
    var press:Array<String>  = [] // 压力位
    var risk:CGFloat         = 0.0 // 警戒位
    var type:Int              = 0   // 类型: 1短线 2长线
}
