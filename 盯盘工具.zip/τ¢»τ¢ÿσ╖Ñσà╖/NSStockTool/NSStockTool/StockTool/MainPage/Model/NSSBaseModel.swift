//
//  NSSBaseModel.swift
//  NSStockTool
//
//  Created by caojinguo on 2021/4/28.
//

import Foundation
import HandyJSON

class NSSBaseModel: HandyJSON {
    
    
    required init() {}
    
}
