//
//  NSSStockListResponse.swift
//  NSStockTool
//
//  Created by caojinguo on 2021/4/28.
//

import Foundation

class NSSStockListResponse: NSSBaseModel {
    var data:Array<NSSStockModel> = []
    
//    required init() {}
    
    
}
