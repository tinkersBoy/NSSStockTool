//
//  NSSStockItemView.swift
//  NSStockTool
//
//  Created by caojinguo on 2021/4/29.
//

import AppKit
import Foundation

class NSSStockItemView: NSView {
    var pressPriceLabel:NSTextField   = NSSStockItemView.defaultLab()
    var nameLabel:NSTextField         = NSSStockItemView.defaultLab()
    var symbolLabel:NSTextField       = NSSStockItemView.defaultLab()
    var pricelLabel:NSTextField       = NSSStockItemView.defaultLab()
    var holdLabel:NSTextField         = NSSStockItemView.defaultLab()
    var holdWarnLabel:NSTextField     = NSSStockItemView.defaultLab()
    var pressWarnLabel:NSTextField    = NSSStockItemView.defaultLab()
    var runPriceLabel:NSTextField     = NSSStockItemView.defaultLab()
    
    func setContentData(itemModel:NSSDingStockModel) -> () {
        let defaultColor:NSColor = NSSFormatUtil.defaultColor()
        let redColor:NSColor     = NSColor.stockRedColor()
        let greenColor:NSColor   = NSColor.stockGreenColor()
        let fontSize:CGFloat     = 13.0
        
        var i = 0
        
        // 股票名
        var typeStr:String               = ""
        if itemModel.type == 1 {
            typeStr = "短"
        }else if itemModel.type == 2  {
            typeStr = "长"
        }
        self.nameLabel.x                 = self.frameXWithIndex(i: i)
        self.nameLabel.width             = self.columnWidthForIndex(i: i)
        let nameStr:String               = itemModel.name as String
        self.nameLabel.attributed.string = NSSFormatUtil.stockAttributedstring(name: typeStr,
                                                                            dataStr: nameStr,
                                                                          nameColor: defaultColor,
                                                                          dataColor: defaultColor,
                                                                       dataFontSize: fontSize)
        i += 1
        
        let  priceC                        = itemModel.percent >= 0 ? redColor : greenColor
        
        // 当前价
        self.pricelLabel.x                 = self.frameXWithIndex(i: i)
        self.pricelLabel.width             = self.columnWidthForIndex(i: i)
        let price:String                   = String(format:"%.2f",itemModel.current)
        self.pricelLabel.attributed.string = NSSFormatUtil.stockAttributedstring(name: price, nameColor: priceC, fontSize: fontSize)
        i += 1
        
        // 支撑位
        self.holdLabel.x                 = self.frameXWithIndex(i: i)
        self.holdLabel.width             = self.columnWidthForIndex(i: i)
        self.holdLabel.attributed.string = NSSFormatUtil.stockPriceArrayAttributedstring(arr: itemModel.hold, nameColor: NSColor.magenta, fontSize: fontSize)
        i += 1
        
        // 压力位
        self.pressPriceLabel.x                 = self.frameXWithIndex(i: i)
        self.pressPriceLabel.width             = self.columnWidthForIndex(i: i)
        self.pressPriceLabel.attributed.string = NSSFormatUtil.stockPriceArrayAttributedstring(arr: itemModel.press, nameColor: redColor, fontSize: fontSize)
        i += 1
        
        // 涨跌
        let changePer                      = String(format:"%.2f",itemModel.percent) + "%"
        self.symbolLabel.x                 = self.frameXWithIndex(i: i)
        self.symbolLabel.width             = self.columnWidthForIndex(i: i)
        self.symbolLabel.attributed.string = NSSFormatUtil.stockAttributedstring(name: changePer, nameColor: priceC, fontSize: fontSize)
        i += 1
        
        // 警戒位
        self.runPriceLabel.isHidden          = (itemModel.risk == 0)
        let runPriceStr                      = String(format:"%.2f",itemModel.risk)
        self.runPriceLabel.x                 = self.frameXWithIndex(i: i)
        self.runPriceLabel.width             = self.columnWidthForIndex(i: i)
        self.runPriceLabel.attributed.string = NSSFormatUtil.stockAttributedstring(name: runPriceStr, nameColor: defaultColor, fontSize: fontSize)
        i += 1
        
        
        // 支撑位告警
        let  hold                            = NSSFormatUtil.priceByIndex(index: 0, arr: itemModel.hold)
        self.holdWarnLabel.isHidden          = !NSSFormatUtil.isNearTarPriceWarn(old: CGFloat(hold),
                                                                                fresh: itemModel.current)
        let  holdWarn:String                 = NSSFormatUtil.isSHBigStock(symbol: itemModel.symbol as String) ? "建议低吸" : "建议买入"
        if NSSFormatUtil.isSHBigStock(symbol: itemModel.symbol as String) {
            self.holdWarnLabel.isHidden      = !NSSFormatUtil.isNearBigStock(old: CGFloat(hold), fresh: itemModel.current)
        }
        self.holdWarnLabel.x                 = self.frameXWithIndex(i: i)
        self.holdWarnLabel.width             = self.columnWidthForIndex(i: i)

        self.holdWarnLabel.attributed.string = NSSFormatUtil.stockAttributedstring(name: holdWarn, nameColor: defaultColor, fontSize: fontSize)
        i += 1
        
        // 压力位告警
        let  press                            = NSSFormatUtil.priceByIndex(index: 0, arr: itemModel.press)
        self.pressWarnLabel.isHidden          = !NSSFormatUtil.isNearTarPriceWarn(old: CGFloat(press),
                                                                         fresh: itemModel.current)
        let  pressWarn:String                 = NSSFormatUtil.isSHBigStock(symbol: itemModel.symbol as String) ? "建议高抛" : "建议卖出"
        if NSSFormatUtil.isSHBigStock(symbol: itemModel.symbol as String) {
            self.pressWarnLabel.isHidden      = !NSSFormatUtil.isNearBigStock(old: CGFloat(press), fresh: itemModel.current)
        }
        self.pressWarnLabel.x                 = self.frameXWithIndex(i: i)
        self.pressWarnLabel.width             = self.columnWidthForIndex(i: i)

        self.pressWarnLabel.attributed.string = NSSFormatUtil.stockAttributedstring(name: pressWarn, nameColor: defaultColor, fontSize: fontSize)
        i += 1
        
        self.addSubview(self.nameLabel)
        self.addSubview(self.pricelLabel)
        self.addSubview(self.holdLabel)
        self.addSubview(self.symbolLabel)
        self.addSubview(self.pressPriceLabel)
        self.addSubview(self.holdWarnLabel)
        self.addSubview(self.pressWarnLabel)
        self.addSubview(self.runPriceLabel)
        
        let isBigHeight  = (itemModel.hold.count == 3 || itemModel.press.count == 3)
        if isBigHeight {
            self.height                 = 60.0
            self.nameLabel.height       = 56.0
            self.pricelLabel.height     = 56.0
            self.holdLabel.height       = 56.0
            self.symbolLabel.height     = 56.0
            self.pressPriceLabel.height = 56.0
            self.holdWarnLabel.height   = 56.0
            self.pressWarnLabel.height  = 56.0
            self.runPriceLabel.height   = 56.0
        }
        
    }
    
    func frameXWithIndex(i:Int) -> CGFloat {
        var tempY:CGFloat = 0.0
        tempY             = self.maxFrameX(i: i, arr: self.columnWidthArr()) + 5.0;
        return tempY
    }
    func columnWidthForIndex(i:Int) -> CGFloat {
        let arr:Array = self.columnWidthArr()
        if arr.count <= i {
            return  80.0
        }
        
        return CGFloat(arr[i])
    }
    
    func columnWidthArr() -> Array<Double> {
        let arr:Array = [(100.0),  // 股票名
                         (100.0),  // 当前价
                         (80.0),  //  支撑位
                         (80.0),  //  压力位
                         (80.0),  //  涨跌
                         (80.0),  //  警戒位
                         (90.0), //  支撑告警
                         (90.0), //  压力位告警
        ]
        return arr
    }
    
    func maxFrameX(i:Int, arr:Array<Double>) -> CGFloat {
        if i == 0 {
            return 0.0
        }
        let space:CGFloat = (5.0) * CGFloat(i)
        let arr:Array = self.columnWidthArr()
        
        var width:CGFloat = 0.0
        for index in 0...(i-1) {
            if arr.count <= i {
                return CGFloat(width + space)
            }else {
                let everyWidth:CGFloat = CGFloat(arr[index])
                width = width + everyWidth
            }
        }
        return CGFloat(width + space)
    }
    
    
    static  func defaultLab() -> NSTextField {
        let textField:NSTextField   = NSTextField.init()
        textField.frame             = NSRect(x: 1, y: 0.0,
                                            width: 80.0, height: 36.0)
        textField.isEnabled         = false
        return textField
    }
    
}
