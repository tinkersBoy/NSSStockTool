//
//  NSSStockHeaderView.swift
//  NSStockTool
//
//  Created by caojinguo on 2021/5/21.
//

import AppKit
import Foundation

class NSSStockHeaderView: NSView {
    var pressPriceLabel:NSTextField   = NSSStockHeaderView.defaultLab()
    var nameLabel:NSTextField         = NSSStockHeaderView.defaultLab()
    var symbolLabel:NSTextField       = NSSStockHeaderView.defaultLab()
    var pricelLabel:NSTextField       = NSSStockHeaderView.defaultLab()
    var holdLabel:NSTextField         = NSSStockHeaderView.defaultLab()
    var holdWarnLabel:NSTextField     = NSSStockHeaderView.defaultLab()
    var pressWarnLabel:NSTextField    = NSSStockHeaderView.defaultLab()
    var runPriceLabel:NSTextField     = NSSStockHeaderView.defaultLab()
    
    func setContentData(itemModel:NSSDingStockModel) -> () {
        let defaultColor:NSColor = NSSFormatUtil.defaultColor()
        let fontSize:CGFloat     = 13.0
        
        var i = 0
        
        // 股票名
        self.nameLabel.x                 = self.frameXWithIndex(i: i)
        self.nameLabel.width             = self.columnWidthForIndex(i: i)
        self.nameLabel.attributed.string = NSSFormatUtil.stockAttributedstring(name: "股票名", nameColor: defaultColor, fontSize: fontSize)
        i += 1

        
        // 当前价
        self.pricelLabel.x                 = self.frameXWithIndex(i: i)
        self.pricelLabel.width             = self.columnWidthForIndex(i: i)
        self.pricelLabel.attributed.string = NSSFormatUtil.stockAttributedstring(name: "当前价", nameColor: defaultColor, fontSize: fontSize)
        i += 1
        
        // 支撑位
        self.holdLabel.x                 = self.frameXWithIndex(i: i)
        self.holdLabel.width             = self.columnWidthForIndex(i: i)
        self.holdLabel.attributed.string = NSSFormatUtil.stockAttributedstring(name: "支撑位", nameColor: defaultColor, fontSize: fontSize)
        i += 1
        
        // 压力位
        self.pressPriceLabel.x                 = self.frameXWithIndex(i: i)
        self.pressPriceLabel.width             = self.columnWidthForIndex(i: i)
        self.pressPriceLabel.attributed.string = NSSFormatUtil.stockAttributedstring(name: "压力位", nameColor: defaultColor, fontSize: fontSize)
        i += 1
        
        // 涨跌
        self.symbolLabel.x                 = self.frameXWithIndex(i: i)
        self.symbolLabel.width             = self.columnWidthForIndex(i: i)
        self.symbolLabel.attributed.string = NSSFormatUtil.stockAttributedstring(name: "涨跌", nameColor: defaultColor, fontSize: fontSize)
        i += 1
        
        // 警戒位
        self.runPriceLabel.x                 = self.frameXWithIndex(i: i)
        self.runPriceLabel.width             = self.columnWidthForIndex(i: i)
        self.runPriceLabel.attributed.string = NSSFormatUtil.stockAttributedstring(name: "警戒位", nameColor: defaultColor, fontSize: fontSize)
        i += 1
        
        // 支撑位告警
        self.holdWarnLabel.x                 = self.frameXWithIndex(i: i)
        self.holdWarnLabel.width             = self.columnWidthForIndex(i: i)
        self.holdWarnLabel.attributed.string = NSSFormatUtil.stockAttributedstring(name: "支撑告警", nameColor: defaultColor, fontSize: fontSize)
        i += 1
        
        // 压力位告警
        self.pressWarnLabel.x                 = self.frameXWithIndex(i: i)
        self.pressWarnLabel.width             = self.columnWidthForIndex(i: i)
        self.pressWarnLabel.attributed.string = NSSFormatUtil.stockAttributedstring(name: "压力告警", nameColor: defaultColor, fontSize: fontSize)
        i += 1
        
        self.addSubview(self.nameLabel)
        self.addSubview(self.symbolLabel)
        self.addSubview(self.pricelLabel)
        self.addSubview(self.holdLabel)
        self.addSubview(self.pressPriceLabel)
        self.addSubview(self.runPriceLabel)
        self.addSubview(self.holdWarnLabel)
        self.addSubview(self.pressWarnLabel)
    }
    
    func frameXWithIndex(i:Int) -> CGFloat {
        var tempY:CGFloat = 0.0
        tempY             = self.maxFrameX(i: i, arr: self.columnWidthArr()) + 5.0;
        return tempY
    }
    func columnWidthForIndex(i:Int) -> CGFloat {
        let arr:Array = self.columnWidthArr()
        if arr.count <= i {
            return  80.0
        }
        
        return CGFloat(arr[i])
    }
    
    func columnWidthArr() -> Array<Double> {
        let arr:Array = [(100.0),  // 股票名
                         (100.0),  // 当前价
                         (80.0),  //  支撑位
                         (80.0),  //  压力位
                         (80.0),  //  涨跌
                         (80.0),  //  警戒位
                         (90.0), //  支撑告警
                         (90.0), //  压力位告警
        ]
        return arr
    }
    
    func maxFrameX(i:Int, arr:Array<Double>) -> CGFloat {
        if i == 0 {
            return 0.0
        }
        let space:CGFloat = (5.0) * CGFloat(i)
        let arr:Array = self.columnWidthArr()
        
        var width:CGFloat = 0.0
        for index in 0...(i-1) {
            if arr.count <= i {
                return CGFloat(width + space)
            }else {
                let everyWidth:CGFloat = CGFloat(arr[index])
                width = width + everyWidth
            }
        }
        return CGFloat(width + space)
    }
    
    
    static  func defaultLab() -> NSTextField {
        let textField:NSTextField   = NSTextField.init()
        textField.frame             = NSRect(x: 1, y: 0.0,
                                            width: 80.0, height: 20.0)
        textField.isEnabled         = false
        return textField
    }
    
}
