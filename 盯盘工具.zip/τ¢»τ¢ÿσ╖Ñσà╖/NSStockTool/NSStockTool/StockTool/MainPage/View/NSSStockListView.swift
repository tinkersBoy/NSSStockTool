//
//  NSSStockListView.swift
//  NSStockTool
//
//  Created by caojinguo on 2021/4/29.
//

import Foundation
import AppKit

class NSSStockListView: NSView {
    
    func setContentData(listResponse:NSSDingStockListResponse) -> (CGFloat) {
        for view:NSView in self.subviews {
            view.removeFromSuperview()
        }
        var height:CGFloat = 0.0
        var i = 0;
        if listResponse.data.count > 0 {
            for itemModel:NSSDingStockModel in listResponse.data {
                let stockItemView:NSSStockItemView = NSSStockItemView.init()
                stockItemView.frame             = NSRect(x: 1, y: Int(height),
                                                         width: Int(self.width), height: Int(40.0))
                stockItemView.setContentData(itemModel: itemModel)
                self.addSubview(stockItemView)
                i = i + 1
                height = height + stockItemView.height
            }
            // 表头
            let stockHeaderView:NSSStockHeaderView = NSSStockHeaderView.init()
            stockHeaderView.setContentData(itemModel: listResponse.data.first ?? NSSDingStockModel.init())
            stockHeaderView.frame             = NSRect(x: 1, y: Int(height),
                                                       width: Int(self.width), height: Int(20.0))
            self.addSubview(stockHeaderView)
            i = i + 1
            return stockHeaderView.maxY
        }
        return 40.0
    }
    
}
