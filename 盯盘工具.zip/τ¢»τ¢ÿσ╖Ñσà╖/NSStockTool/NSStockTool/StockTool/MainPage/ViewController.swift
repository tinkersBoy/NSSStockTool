//
//  ViewController.swift
//  NSStockTool
//
//  Created by caojinguo on 2021/4/27.
//

import Cocoa
import AttributedString

class ViewController: NSViewController {
    
    var listView:NSSStockListView            = NSSStockListView.init()
    var marketLabel:NSTextField              = ViewController.marketInfoLab(price: 0)
    var configBtn:NSButton                   = ViewController.configBtn()
    var configInfoLab:NSTextField            = ViewController.configInfoLab()
    var cleanBtn:NSButton                    = ViewController.cleanBtn()
    var dateInfoLab:NSTextField              = ViewController.dateLabel()
    var configResponse:NSSFileConfigResponse = NSSFileConfigResponse.init()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let color : CGColor = CGColor.black
        view.layer?.backgroundColor = color
        
        // 大盘
        self.view.addSubview(self.marketLabel)
        self.view.addSubview(self.dateInfoLab)
        
        // 配置
        self.configBtn = NSButton(title: "去配置", target: self, action: #selector(clickChooseBtn))
        self.configBtn.frame        = NSRect(x: 260, y: 0,
                                  width: 70, height: 25)
        self.configBtn.bezelStyle   = NSButton.BezelStyle(rawValue: 2)!
        self.configBtn.alignment    = NSTextAlignment.center
        self.configBtn.isBordered   = true
        self.view.addSubview(self.configBtn)
        self.view.addSubview(self.configInfoLab)
        
        // 盯盘列表
        self.listView.frame = NSRect(x: 1, y: 5.0,
                                width: 1200, height: 50.0)
        self.view.addSubview(self.listView)
        
        self.configResponse = NSSJsonUtil.localFileConfig()
        if self.configResponse.isLocalData {
            self.configInfoLab.placeholderString = NSSJsonUtil.localFileUrl().absoluteString
        }
        var timeInterval:TimeInterval = 0.5
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "HH"// 自定义时间格式
        let time = dateformatter.string(from: Date())
        let hour:Int = Int(time) ?? 10
        dateformatter.dateFormat = "mm"// 自定义时间格式
        let time1 = dateformatter.string(from: Date())
        let min:Int = Int(time1) ?? 0
        
        //
        if (hour <= 9 && min < 30) || (hour == 11 && min > 30) || (hour == 12) || (hour >= 15 && min > 1) {
            timeInterval = 5.0
            self.refreshDataByTimer(marketLabel: marketLabel)
            self.dateInfoLab.attributed.string = NSSFormatUtil.stockAttributedstring(name: self.currentDateStr(), nameColor: NSColor.systemGray, fontSize: 15.0)
        }
        
        Timer.scheduledTimer(withTimeInterval: timeInterval, repeats: true) { timer in
//            print(">>> Timer has Callback!")
            self.refreshDataByTimer(marketLabel: self.marketLabel)
            self.dateInfoLab.placeholderString = self.currentDateStr()
        }
        
        
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }
    
    func refreshDataByTimer(marketLabel: NSTextField) -> () {
        self.refreshMarketPrice {
            (listResponse) in
            if listResponse.data.count > 0 {
                let stockModel:NSSStockModel = listResponse.data.first!
                self.updateMarketInfo(stockModel: stockModel, textField: marketLabel)
                let dateStr = self.currentDateStr()
                NSSTimeDivisionManager.sharedInstance.addTimeAmountData(dateStr: dateStr, amount: stockModel.amount)
            }
        }
        if self.configResponse.list.count > 0 {
            self.refreshConfigStockPrice(configResponse: self.configResponse)
        }
    }
    
    // 上证指数
    func refreshMarketPrice(complectionHandle:@escaping complection) -> () {
        let network:NSSMainPageNetwork = NSSMainPageNetwork.sharedInstance
        let para:NSDictionary = NSDictionary.init(object: "mar", forKey: "key" as NSCopying)
        network.fetchByParams(param: para) {
            (listResponse) in
            complectionHandle(listResponse)
        }
    }
    // 个股
    func refreshConfigStockPrice(configResponse:NSSFileConfigResponse) -> () {
        if configResponse.list.count > 0 {
            let network:NSSMainPageNetwork = NSSMainPageNetwork.sharedInstance
            network.fetchDingPanDataByConfigResponse(config: configResponse) {
                (dingStockListResponse) in
                if dingStockListResponse.data.count > 0 {
                    self.listView.height = 40.0 * CGFloat(dingStockListResponse.data.count)
                    NSSJsonUtil.appendSymbolInfo(config: configResponse, listResponse: dingStockListResponse)
                    let height = self.listView.setContentData(listResponse: dingStockListResponse)
                    self.listView.height  = height + 5.0
                    self.marketLabel.y    = self.listView.maxY  + 10.0
                    self.configBtn.y      = self.listView.maxY  + 10.0
                    self.configInfoLab.y  = self.listView.maxY  + 10.0
                    self.dateInfoLab.y    = self.listView.maxY  + 15.0
                }
            }
        }
    }
    

    @objc func clickChooseBtn(_ sender: NSButton) -> () {
        print("-----click")
        let openPanel:NSOpenPanel  = NSOpenPanel.init()
        openPanel.prompt           = "打开"
        openPanel.allowedFileTypes = ["txt","doc","json"]
        openPanel.directoryURL     = nil
        openPanel.begin { (modelResponse) in
            if (modelResponse.rawValue == 1) {
                if (openPanel.url != nil) {
                    // 读取配置文件
                    let URL:URL = openPanel.url!
                    self.configInfoLab.placeholderString = URL.absoluteString
                    do {
                        let fileHandle:FileHandle = try FileHandle.init(forReadingFrom: URL)
                        let json:String = NSString.init(data: fileHandle.readDataToEndOfFile(), encoding: String.Encoding.utf8.rawValue)! as String
                        NSSJsonUtil.isValidJson(jsonString: json) {
                            (configResponse) in
                            self.configResponse = configResponse
                            self.refreshConfigStockPrice(configResponse: configResponse)
                            NSSJsonUtil.saveFileUrl(URL: URL)
                        }
                    } catch {
                        
                    }
                    print(openPanel.url ?? "")
                }
            }
        }
    }
    
    @objc func clickCleanBtn(_ sender: NSButton) -> () {
        print("-----click")
        
    }
    
    
    /// Getter
    func updateMarketInfo(stockModel: NSSStockModel,textField: NSTextField) -> () {
        let change:CGFloat          = stockModel.chg
        let num                     = (stockModel.current)
        let changeStr:String        = String(format:"%.2f",change)
        let changePer:String        = String(format:"%.2f",stockModel.percent) + "%"
        let open                    = String(format:"%.2f",stockModel.open)
        let high                    = String(format:"%.2f",stockModel.high)
        let low                     = String(format:"%.2f",stockModel.low)
        let amount:CGFloat          = stockModel.amount / 100000000.0;
        let amountStr:String        = String(format:"%.2f",amount)
        let changeColor:NSColor = change < 0.0 ? NSColor.stockGreenColor()
            : NSColor.stockRedColor()
        
        let array: [AttributedString] = [
            .init(
                """
                \("上证指数: ", .font(.systemFont(ofSize: 16, weight: .medium)))
                """,
                .paragraph(.alignment(.left))
            ),
            """
            \(wrap: .embedding(
                """
                \(num) \(" " + changeStr + "  " + changePer, .font(.systemFont(ofSize: 12, weight: .medium)), .foreground(changeColor))
                """
            ), .font(.systemFont(ofSize: 32, weight: .medium)), .foreground(changeColor))
            """,
            
            """
            \(wrap: .embedding(
                """

                开\(" " + open + "             低 " + low, .font(.systemFont(ofSize: 16, weight: .medium)), .foreground(changeColor))
                """
            ), .font(.systemFont(ofSize: 12, weight: .medium)))
            """,
            
            """
            \(wrap: .embedding(
                """
                高 \(high, .font(.systemFont(ofSize: 16, weight: .medium)), .foreground(NSColor.stockRedColor()))
                额 \(amountStr + "亿", .font(.systemFont(ofSize: 13, weight: .medium)))
                """
            ), .font(.systemFont(ofSize: 12))
            )
            """
        ]
        
        let string = array.reduce(into: AttributedString(stringLiteral: "")) {
            $0 += $1 + "\n"
        }
        textField.attributed.string = string
        
    }
    
    func currentDateStr() -> String {
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "HH:mm"// 自定义时间格式
        let time:String = dateformatter.string(from: Date())
        return time
    }
    
    static func marketInfoLab(price: CGFloat) -> NSTextField {
        let textField:NSTextField   = NSTextField.init()
        textField.frame             = NSRect(x: 1, y: 0,
                                             width: 238, height: 135)
        textField.isEnabled         = false
        return textField
    }
    
    static func configBtn() -> NSButton {
        let btn:NSButton = NSButton(title: "去配置", target: self, action: #selector(clickChooseBtn))
        return btn
    }
    
    static func configInfoLab() -> NSTextField {
        let textField:NSTextField   = NSTextField.init()
        textField.frame             = NSRect(x: 330, y: 0,
                                             width: 300, height: 50)
        textField.isEnabled         = false
        return textField
    }
    
    static func dateLabel() -> NSTextField {
        let textField:NSTextField   = NSTextField.init()
        textField.frame             = NSRect(x: 150, y: 0,
                                             width: 65, height: 23)
        textField.isEnabled         = false
        return textField
    }
    
    static func cleanBtn() -> NSButton {
        let btn:NSButton = NSButton(title: "清除", target: self, action: #selector(clickCleanBtn))
        return btn
    }
    
}

