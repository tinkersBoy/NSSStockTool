//
//  NSSFormatUtil.swift
//  NSStockTool
//
//  Created by caojinguo on 2021/4/30.
//

import AppKit
import Foundation
import AttributedString

class NSSFormatUtil: NSObject {
    
    static func isSHBigStock(symbol:String) -> Bool {
        return symbol == "SH000001"
    }
    
    // 是否为大盘
    static func isNearBigStock(old:CGFloat, fresh:CGFloat) -> Bool {
        if fabsf(Float(old - fresh)) <= 5.0 {
            return true
        }
        return false
    }
    
    // 从数组获取对应的价格
    static func priceByIndex(index:Int ,arr:Array<String>) -> Float {
        if arr.count <= index  {
            return 0.0
        }
        let price:Float = Float(arr[index]) ?? 0.0
        return price
    }
    
    static func isNearTarPriceWarn(old:CGFloat, fresh:CGFloat) -> Bool {
        if old == fresh {
            return true
        }
        let change:CGFloat = ((fresh - old) / old) * 100.0
        if change >= -1 && change <= 1 {
            return true
        }
        return false
    }
    
    static func isUpWithNewPrice(old:CGFloat, fresh:CGFloat) -> Bool {
        return (fresh >= old) ? true : false
    }
    
    static func changePercentStr(old:CGFloat, fresh:CGFloat) -> String {
        if old == fresh {
            return "0.00%"
        }
        let change:CGFloat = ((fresh - old) / old) * 100.0
        if fresh > old {
            return String(format:"%.3f%%",change)
        }
        return String(format:"%.3f%%",change)
    }
    
    
    static func curPriceColor(old:CGFloat, fresh:CGFloat) -> NSColor {
        if old == fresh {
            return self.defaultColor()
        }
        if fresh > old {
            return NSColor.stockRedColor()
        }
        return NSColor.stockGreenColor()
    }
    
    static func defaultColor() -> NSColor {
        return NSColor.init(red: (138.0/255.0), green: (138.0/255.0), blue: (138.0/255.0), alpha: 1.0)
    }
    
    static func stockAttributedstring(name: String, dataStr: String, nameColor:NSColor, dataColor: NSColor, dataFontSize: CGFloat) -> AttributedString {
        let array: [AttributedString] = [
            .init(
                """
                \(name, .font(.systemFont(ofSize: 9, weight: .medium)), .foreground(nameColor))
                \(dataStr, .font(.systemFont(ofSize: dataFontSize, weight: .medium)), .foreground(dataColor))
                """,
                .paragraph(.alignment(.center))
            ),
        ]
        
        let string = array.reduce(into: AttributedString(stringLiteral: "")) {
            $0 += $1 + "\n"
        }
        return string;
    }
    
    static func stockAttributedstring(name: String, nameColor:NSColor, fontSize: CGFloat) -> AttributedString {
        let array: [AttributedString] = [
            .init(
                """
                \(name, .font(.systemFont(ofSize: fontSize, weight: .medium)), .foreground(nameColor))
                """,
                .paragraph(.alignment(.center))
            ),
        ]
        
        let string = array.reduce(into: AttributedString(stringLiteral: "")) {
            $0 += $1
        }
        return string;
    }
    
    static func stockPriceArrayAttributedstring(arr: Array<String>, nameColor:NSColor, fontSize: CGFloat) -> AttributedString {
        if arr.count == 1 {
            let hold:Float = NSSFormatUtil.priceByIndex(index: 0, arr: arr)
            let holdStr:String                  = String(format:"%.2f",hold)
            return self.stockAttributedstring(name: holdStr, nameColor: nameColor, fontSize: fontSize)
        }else if arr.count == 2 {
            let hold:Float = NSSFormatUtil.priceByIndex(index: 0, arr: arr)
            let holdStr:String                  = String(format:"%.2f",hold)
            
            let holdM:Float = NSSFormatUtil.priceByIndex(index: 1, arr: arr)
            let holdStrM:String                  = String(format:"%.2f",holdM)
            
            return self.stockTwoPriceAttributedstring(name: holdStr, dataStr: holdStrM, nameColor: nameColor, dataColor: nameColor, dataFontSize: fontSize)
        }else if arr.count == 3 {
            let hold:Float = NSSFormatUtil.priceByIndex(index: 0, arr: arr)
            let holdStr:String                  = String(format:"%.2f",hold)
            
            let holdM:Float = NSSFormatUtil.priceByIndex(index: 1, arr: arr)
            let holdStrM:String                  = String(format:"%.2f",holdM)
            
            let holdR:Float = NSSFormatUtil.priceByIndex(index: 2, arr: arr)
            let holdStrR:String                  = String(format:"%.2f",holdR)
            
            return self.stockMulPriceAttributedstring(name: holdStr, dataStr: holdStrM, nameColor: nameColor, dataColor: nameColor, other: holdStrR, dataFontSize: fontSize)
        }
        
        else {
            return self.stockAttributedstring(name: "", nameColor: nameColor, fontSize: fontSize)
        }
    }
    
    // 两个价格展示
    static func stockTwoPriceAttributedstring(name: String, dataStr: String, nameColor:NSColor, dataColor: NSColor, dataFontSize: CGFloat) -> AttributedString {
        let array: [AttributedString] = [
            .init(
                """
                \(name, .font(.systemFont(ofSize: 12.0, weight: .medium)), .foreground(nameColor))
                \(dataStr, .font(.systemFont(ofSize: dataFontSize, weight: .medium)), .foreground(dataColor))
                """,
                .paragraph(.alignment(.center))
            ),
        ]
        
        let string = array.reduce(into: AttributedString(stringLiteral: "")) {
            $0 += $1 + "\n"
        }
        return string;
    }
    // 三个价格展示
    static func stockMulPriceAttributedstring(name: String, dataStr: String, nameColor:NSColor, dataColor: NSColor,other:String, dataFontSize: CGFloat) -> AttributedString {
        let array: [AttributedString] = [
            .init(
                """
                \(name, .font(.systemFont(ofSize: 13.0, weight: .medium)), .foreground(nameColor))
                \(dataStr, .font(.systemFont(ofSize: dataFontSize, weight: .medium)), .foreground(dataColor))
                \(other, .font(.systemFont(ofSize: dataFontSize, weight: .medium)), .foreground(dataColor))
                """,
                .paragraph(.alignment(.center))
            ),
        ]
        
        let string = array.reduce(into: AttributedString(stringLiteral: "")) {
            $0 += $1 + "\n"
        }
        return string;
    }
}
