//
//  NSSJsonUtil.swift
//  NSStockTool
//
//  Created by caojinguo on 2021/4/28.
//

import Foundation
import AppKit
import HandyJSON

typealias configCallback = (NSSFileConfigResponse) ->()

class NSSJsonUtil: NSObject {
    
     static func localFileConfig() -> NSSFileConfigResponse {
        var config:NSSFileConfigResponse = NSSFileConfigResponse.init()
        // 优先读取上次缓存的
        let URL:URL = self.localFileUrl()
        if URL.absoluteString != "empty" {
            // 读取配置文件
            do {
                let fileHandle:FileHandle = try FileHandle.init(forReadingFrom: URL)
                let json:String = NSString.init(data: fileHandle.readDataToEndOfFile(), encoding: String.Encoding.utf8.rawValue)! as String
                NSSJsonUtil.isValidJson(jsonString: json) {
                    (configResponse) in
                    config = configResponse
                    config.isLocalData = true
                }
            } catch {
                
            }
        }
        if config.list.count > 0 {
            return config
        }
        let mainBundle:CFBundle = CFBundleGetMainBundle()
        let cfUrl:CFURL = CFBundleCopyResourceURL(mainBundle, "NSS-config" as CFString, "json" as CFString, nil)
        do {
            let fileHandle:FileHandle = try FileHandle.init(forReadingFrom: cfUrl as URL)
            let json:String = NSString.init(data: fileHandle.readDataToEndOfFile(), encoding: String.Encoding.utf8.rawValue)! as String
            NSSJsonUtil.isValidJson(jsonString: json) {
                (configResponse) in
                config = configResponse
            }
        } catch {
            
        }
        return config
    }
    
    static  func stockString(response:NSSFileConfigResponse) -> NSString {
        if response.list.count  > 0 {
            var  stockString = ""
            for config:NSSConfigModel in response.list {
                if stockString.count == 0 {
                    stockString = config.symbol
                }else {
                    stockString = stockString  + "," + config.symbol
                }
            }
            return stockString as NSString
        }
        return ""
    }
    
    static  func appendSymbolInfo(config:NSSFileConfigResponse, listResponse:NSSDingStockListResponse) -> () {
        let configDict:Dictionary = NSSJsonUtil.dictWithConfigResponse(config: config) as! Dictionary<String, NSSConfigModel>
            if listResponse.data.count > 0 {
                // 大盘置顶
                var isExistBigStock:Bool           = false
                var atIndex:Int                    = 0
                var bigStockItem:NSSDingStockModel = NSSDingStockModel.init()
                bigStockItem.symbol = "SH000001"
                for index in 0...(listResponse.data.count) {
                    if index < listResponse.data.count {
                        let item:NSSDingStockModel = listResponse.data[index]
                        if item.symbol == bigStockItem.symbol {
                            bigStockItem    = item
                            isExistBigStock = true
                            atIndex         = index
                            break
                        }
                    }
                }
                if isExistBigStock {
                    listResponse.data.remove(at: atIndex)
                    listResponse.data.insert(bigStockItem, at: (listResponse.data.count))
                }
                
                for item:NSSDingStockModel in listResponse.data {
                    let configItem:NSSConfigModel = configDict[item.symbol as String] ?? NSSConfigModel.init()
                    if configItem.symbol.count > 0 {
                        item.name  = configItem.name as NSString
                        item.press = configItem.press
                        item.hold  = configItem.hold
                        item.type  = configItem.type
                        item.risk  = configItem.risk
                    }
                }
            }
    }
    
    static func dictWithConfigResponse(config:NSSFileConfigResponse) -> NSDictionary {
        let dict:NSMutableDictionary = NSMutableDictionary.init()
        if config.list.count > 0 {
            for item:NSSConfigModel in config.list {
                dict[item.symbol] = item
            }
        }
        return dict
    }
    
//    static func dictWithDingStockResponse(response:NSSDingStockListResponse) -> NSDictionary {
//        let dict:NSMutableDictionary = NSMutableDictionary.init()
//        if response.data.count > 0 {
//            for item:NSSDingStockModel in response.data {
//                dict[item.symbol] = item
//            }
//        }
//        return dict
//    }
    static func isOpenStockTime() -> Bool {
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "HH"// 自定义时间格式
        let time = dateformatter.string(from: Date())
        let hour:Int = Int(time) ?? 10
        dateformatter.dateFormat = "mm"// 自定义时间格式
        let time1 = dateformatter.string(from: Date())
        let min:Int = Int(time1) ?? 0
        
        //
        if (hour <= 9 && min < 30) || (hour == 11 && min > 30) || (hour == 12) || (hour >= 15 && min > 1) {
            return false
        }
        return true
    }
    
    static func saveTimeAmountData(key:String, value: String) -> () {
        if value.count > 0 {
            let userDefault:UserDefaults = UserDefaults.standard
            userDefault.setValue(value, forKey: key)
            userDefault.synchronize()
        }
    }
    
    static func localTimeAmountData() -> NSSTimeAmountResponse {
        let userDefault:UserDefaults = UserDefaults.standard
//        userDefault.removeObject(forKey: self.dateStr())
        let jsonStr:String = userDefault.string(forKey: self.dateStr())
        ?? "empty"
        if jsonStr.count > 0 {
            return NSSTimeAmountResponse.deserialize(from: jsonStr) ?? NSSTimeAmountResponse.init()
        }
        return NSSTimeAmountResponse.init()
    }
    
    static func saveFileUrl(URL:URL) -> () {
        if URL.absoluteString.count > 0 {
            let userDefault:UserDefaults = UserDefaults.standard
            userDefault.setValue(URL.absoluteString, forKey: "NSS_FileUrlKey")
            userDefault.synchronize()
        }
    }
    
    static func localFileUrl() -> URL {
        let userDefault:UserDefaults = UserDefaults.standard
        let url:String = userDefault.string(forKey: "NSS_FileUrlKey")
        ?? "empty"
        if url.count > 0 {
            return URL.init(string: url) ?? URL.init(string: "empty")!
        }
        return URL.init(string: "empty")!
    }
    
    
    static  func isValidJson(jsonString:String, callback:@escaping configCallback) -> () {
        let listResponse = NSSFileConfigResponse.deserialize(from: jsonString)
        if (listResponse != nil) {
            callback(listResponse!)
        }
    }
    
    static func dateStr() -> String {
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "yyyy-MM-dd"// 自定义时间格式
        let time = dateformatter.string(from: Date())
        return time
    }
}
