//
//  NSSTimeDivisionManager.swift
//  NSStockTool
//
//  Created by caojinguo on 2021/5/14.
//

import Foundation

class NSSTimeDivisionManager: NSObject {
    var listResponse:NSSTimeAmountResponse = NSSTimeAmountResponse.init()
    var isCheckLocalData:Bool = false
    
    class var sharedInstance: NSSTimeDivisionManager {
        struct Static {
            static let instance: NSSTimeDivisionManager = NSSTimeDivisionManager()
        }
        return Static.instance
    }
    
    func addTimeAmountData(dateStr:String,amount:CGFloat) -> () {
        if !self.isCheckLocalData {
            self.isCheckLocalData = true
            let localResponse:NSSTimeAmountResponse = NSSJsonUtil.localTimeAmountData()
            if localResponse.data.count > 0 {
                for model:NSSTimeAmountModel in localResponse.data {
                    let tempA = Float(model.amountStr)
                    model.amount = CGFloat(tempA ?? 0.0)
                    let tempD = Float(model.diffStr)
                    model.diff = CGFloat(tempD ?? 0.0)
                    self.listResponse.data.append(model)
                    self.listResponse.dataDict[model.dateT] = model
                }
            }
        }
        
        if !NSSJsonUtil.isOpenStockTime() {
            return
        }
        
        if amount == 0.0 {
            return
        }
        let min:Int = self.minDate()
        if min % 5 != 0 {
            return
        }
        if self.listResponse.currentDate.count == 0 {
            self.listResponse.currentDate = self.dateStr()
        }
        
        if self.listResponse.dataDict.keys.contains(dateStr) {

        }else {
            let amoutModel:NSSTimeAmountModel = NSSTimeAmountModel.init()
            amoutModel.dateT     = dateStr
            amoutModel.amount    = amount
            amoutModel.amountStr = String(format:"%.2f",amount)
            self.listResponse.dataDict.updateValue(amoutModel, forKey: dateStr)
            if self.listResponse.data.count > 0 && self.listResponse.data.count <= 50 {
                let compareAmountModel:NSSTimeAmountModel = self.listResponse.data.last!
                let compareAmount  = compareAmountModel.amount
                amoutModel.diff    = amoutModel.amount - compareAmount
                amoutModel.diffStr = String(format:"%.2f",amoutModel.diff)
                self.listResponse.data.append(amoutModel)
            }else {
                self.listResponse.data.append(amoutModel)
            }
            // 保存到本地
            let jsonStr:String = self.listResponse.toJSONString() ?? ""
            if jsonStr.count > 0 {
                NSSJsonUtil.saveTimeAmountData(key:self.listResponse.currentDate,value:jsonStr)
            }
        }
        
    }
    
    func minDate() -> Int {
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "mm"// 自定义时间格式
        let time = dateformatter.string(from: Date())
        let min:Int = Int(time) ?? 0
        return min
    }
    
    func dateStr() -> String {
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "yyyy-MM-dd"// 自定义时间格式
        let time = dateformatter.string(from: Date())
        return time
    }
}
