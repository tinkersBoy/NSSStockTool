//
//  NSSMainPageNetwork.swift
//  NSStockTool
//
//  Created by caojinguo on 2021/4/28.
//

import Foundation
import Alamofire
import HandyJSON

typealias complection     = (NSSStockListResponse) ->()
typealias listComplection = (NSSDingStockListResponse) ->()

class NSSMainPageNetwork: NSObject {
    
    class var sharedInstance: NSSMainPageNetwork {
        struct Static {
            static let instance: NSSMainPageNetwork = NSSMainPageNetwork()
        }
        return Static.instance
    }
    
    
    // 请求个股
    
    func fetchDingPanDataByConfigResponse(config:NSSFileConfigResponse, complectionHandle:@escaping listComplection) -> () {
        let stockUrlPara:String = NSSJsonUtil.stockString(response: config) as String
        let timeStamp:String    = Date().milliStamp
        let url = "https://stock.xueqiu.com/v5/stock/realtime/quotec.json?symbol=" + stockUrlPara + "&_=" + timeStamp
        let headers: HTTPHeaders = [
            "xq_a_token": "d736618e6e9437e6742c4e1f24a9ec4dbe1bd78a",
            "Accept": "application/json"
        ]
        AF.request(url, headers: headers).responseJSON { response in
            switch response.result {
            case .success(let json):
//                print("获取股票数据成功")
//                print("\(json)")
                let dict = json as! Dictionary<String,AnyObject>
                let listResponse = NSSDingStockListResponse.deserialize(from: dict)
                if (listResponse != nil) {
                    complectionHandle(listResponse!)
                }
            case.failure(let error):
                print("\(error)")
            }
        }
    }
    
    // 上证单独处理
    func fetchByParams(param:NSDictionary, complectionHandle:@escaping complection) -> () {
        let timeStamp:String    = Date().milliStamp
        let url = "https://stock.xueqiu.com/v5/stock/realtime/quotec.json?symbol=SH000001&_=" + timeStamp
        let headers: HTTPHeaders = [
            "xq_a_token": "d736618e6e9437e6742c4e1f24a9ec4dbe1bd78a",
            "Accept": "application/json"
        ]
        
        AF.request(url, headers: headers).responseJSON { response in
            switch response.result {
            case .success(let json):
//                print("获取股票数据成功")
//                print("\(json)")
                let dict = json as! Dictionary<String,AnyObject>
                let listResponse = NSSStockListResponse.deserialize(from: dict)
                if (listResponse != nil) {
                    complectionHandle(listResponse!)
                }
            case.failure(let error):
                print("\(error)")
            }
        }
    }
    
}
