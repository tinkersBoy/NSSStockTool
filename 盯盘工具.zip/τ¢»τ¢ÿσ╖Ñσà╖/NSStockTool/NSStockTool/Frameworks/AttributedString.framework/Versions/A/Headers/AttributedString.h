//
//  AttributedString.h
//  AttributedString
//
//  Created by Lee on 2019/11/18.
//  Copyright © 2019 LEE. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AttributedString.
FOUNDATION_EXPORT double AttributedStringVersionNumber;

//! Project version string for AttributedString.
FOUNDATION_EXPORT const unsigned char AttributedStringVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AttributedString/PublicHeader.h>


